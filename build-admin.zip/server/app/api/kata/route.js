"use strict";
(() => {
var exports = {};
exports.id = 302;
exports.ids = [302];
exports.modules = {

/***/ 53524:
/***/ ((module) => {

module.exports = require("@prisma/client");

/***/ }),

/***/ 22037:
/***/ ((module) => {

module.exports = require("os");

/***/ }),

/***/ 47044:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  headerHooks: () => (/* binding */ headerHooks),
  originalPathname: () => (/* binding */ originalPathname),
  requestAsyncStorage: () => (/* binding */ requestAsyncStorage),
  routeModule: () => (/* binding */ routeModule),
  serverHooks: () => (/* binding */ serverHooks),
  staticGenerationAsyncStorage: () => (/* binding */ staticGenerationAsyncStorage),
  staticGenerationBailout: () => (/* binding */ staticGenerationBailout)
});

// NAMESPACE OBJECT: ./app/api/kata/route.ts
var route_namespaceObject = {};
__webpack_require__.r(route_namespaceObject);
__webpack_require__.d(route_namespaceObject, {
  GET: () => (GET),
  POST: () => (POST)
});

// EXTERNAL MODULE: ./node_modules/next/dist/server/node-polyfill-headers.js
var node_polyfill_headers = __webpack_require__(42394);
// EXTERNAL MODULE: ./node_modules/next/dist/server/future/route-modules/app-route/module.js
var app_route_module = __webpack_require__(69692);
// EXTERNAL MODULE: ./node_modules/next/dist/server/future/route-kind.js
var route_kind = __webpack_require__(19513);
// EXTERNAL MODULE: ./node_modules/next/dist/server/web/exports/next-response.js
var next_response = __webpack_require__(89335);
// EXTERNAL MODULE: ./lib/prisma.ts
var prisma = __webpack_require__(17196);
;// CONCATENATED MODULE: ./app/api/kata/route.ts


async function POST(req) {
    try {
        const body = await req.json();
        const { categoryId, name, serviceId, videos } = body;
        if (!name) {
            return new next_response/* default */.Z("Name is required", {
                status: 400
            });
        }
        if (!categoryId) {
            return new next_response/* default */.Z("Category id is required", {
                status: 400
            });
        }
        if (!serviceId) {
            return new next_response/* default */.Z("Service id is required", {
                status: 400
            });
        }
        if (!videos || !videos.length) {
            return new next_response/* default */.Z("Images are required", {
                status: 400
            });
        }
        const kata = await prisma/* default */.Z.kata.create({
            data: {
                categoryId,
                name,
                serviceId,
                videos: {
                    create: [
                        ...videos.map((videos)=>videos)
                    ]
                }
            }
        });
        return next_response/* default */.Z.json(kata);
    } catch (error) {
        console.log("[COUPON_POST]", error);
        return new next_response/* default */.Z("Internal error", {
            status: 500
        });
    }
}
async function GET(req) {
    try {
        const { searchParams } = new URL(req.url);
        const categoryId = searchParams.get("categoryId") || undefined;
        const serviceId = searchParams.get("serviceId") || undefined;
        const kata = await prisma/* default */.Z.kata.findMany({
            where: {
                categoryId,
                serviceId
            },
            include: {
                videos: true,
                category: true,
                service: true
            },
            orderBy: {
                createdAt: "desc"
            }
        });
        return next_response/* default */.Z.json(kata);
    } catch (error) {
        console.log("[PRODUCTS_GET]", error);
        return new next_response/* default */.Z("Internal error", {
            status: 500
        });
    }
}

;// CONCATENATED MODULE: ./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?page=%2Fapi%2Fkata%2Froute&name=app%2Fapi%2Fkata%2Froute&pagePath=private-next-app-dir%2Fapi%2Fkata%2Froute.ts&appDir=C%3A%5CUsers%5CLEGION%5CDocuments%5CAAKHUL%5CDiSign%5CApp%5Cdisign-admin%5Capp&appPaths=%2Fapi%2Fkata%2Froute&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!

// @ts-ignore this need to be imported from next/dist to be external


// @ts-expect-error - replaced by webpack/turbopack loader

const AppRouteRouteModule = app_route_module.AppRouteRouteModule;
// We inject the nextConfigOutput here so that we can use them in the route
// module.
const nextConfigOutput = ""
const routeModule = new AppRouteRouteModule({
    definition: {
        kind: route_kind.RouteKind.APP_ROUTE,
        page: "/api/kata/route",
        pathname: "/api/kata",
        filename: "route",
        bundlePath: "app/api/kata/route"
    },
    resolvedPagePath: "C:\\Users\\LEGION\\Documents\\AAKHUL\\DiSign\\App\\disign-admin\\app\\api\\kata\\route.ts",
    nextConfigOutput,
    userland: route_namespaceObject
});
// Pull out the exports that we need to expose from the module. This should
// be eliminated when we've moved the other routes to the new format. These
// are used to hook into the route.
const { requestAsyncStorage , staticGenerationAsyncStorage , serverHooks , headerHooks , staticGenerationBailout  } = routeModule;
const originalPathname = "/api/kata/route";


//# sourceMappingURL=app-route.js.map

/***/ }),

/***/ 17196:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _prisma_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(53524);
/* harmony import */ var _prisma_client__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_prisma_client__WEBPACK_IMPORTED_MODULE_0__);

const prismadb = globalThis.prisma || new _prisma_client__WEBPACK_IMPORTED_MODULE_0__.PrismaClient();
if (false) {}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (prismadb);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [587,501,335], () => (__webpack_exec__(47044)));
module.exports = __webpack_exports__;

})();