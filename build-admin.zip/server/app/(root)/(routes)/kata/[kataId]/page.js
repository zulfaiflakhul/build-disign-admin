(() => {
var exports = {};
exports.id = 946;
exports.ids = [946];
exports.modules = {

/***/ 53524:
/***/ ((module) => {

"use strict";
module.exports = require("@prisma/client");

/***/ }),

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 98704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 5868:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/app-render");

/***/ }),

/***/ 41844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 96624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 75281:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/route-modules/route-module");

/***/ }),

/***/ 57085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 20199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 66864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 86819:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context");

/***/ }),

/***/ 39569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 52210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 35359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 17160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 30893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 12336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 17887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 98735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 60120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 68231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 54614:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix");

/***/ }),

/***/ 53750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 70982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 79618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 78423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 98658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 39491:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 82361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 57147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 13685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 95687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 22037:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 12781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 76224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 73837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 59796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 5061:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7262);
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(19513);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(31823);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(12502);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
// @ts-ignore this need to be imported from next/dist to be external


const AppPageRouteModule = next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__.AppPageRouteModule;
// We inject the tree and pages here so that we can use them in the route
// module.
const tree = {
        children: [
        '',
        {
        children: [
        '(root)',
        {
        children: [
        '(routes)',
        {
        children: [
        'kata',
        {
        children: [
        '[kataId]',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 11564)), "C:\\Users\\LEGION\\Documents\\AAKHUL\\DiSign\\App\\disign-admin\\app\\(root)\\(routes)\\kata\\[kataId]\\page.tsx"],
          
        }]
      },
        {
        
        
      }
      ]
      },
        {
        'loading': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 76910)), "C:\\Users\\LEGION\\Documents\\AAKHUL\\DiSign\\App\\disign-admin\\app\\(root)\\(routes)\\kata\\loading.tsx"],
        
      }
      ]
      },
        {
        
        
      }
      ]
      },
        {
        'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 65067)), "C:\\Users\\LEGION\\Documents\\AAKHUL\\DiSign\\App\\disign-admin\\app\\(root)\\layout.tsx"],
'not-found': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 95493, 23)), "next/dist/client/components/not-found-error"],
        metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 57481))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
      }
      ]
      },
        {
        'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 51921)), "C:\\Users\\LEGION\\Documents\\AAKHUL\\DiSign\\App\\disign-admin\\app\\layout.tsx"],
'not-found': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 95493, 23)), "next/dist/client/components/not-found-error"],
        metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 57481))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
      }
      ]
      }.children;
const pages = ["C:\\Users\\LEGION\\Documents\\AAKHUL\\DiSign\\App\\disign-admin\\app\\(root)\\(routes)\\kata\\[kataId]\\page.tsx"];

// @ts-expect-error - replaced by webpack/turbopack loader

const __next_app_require__ = __webpack_require__
const __next_app_load_chunk__ = () => Promise.resolve()
const originalPathname = "/(root)/(routes)/kata/[kataId]/page";
const __next_app__ = {
    require: __next_app_require__,
    loadChunk: __next_app_load_chunk__
};

// Create and export the route module that will be consumed.
const routeModule = new AppPageRouteModule({
    definition: {
        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.APP_PAGE,
        page: "/(root)/(routes)/kata/[kataId]/page",
        pathname: "/kata/[kataId]",
        // The following aren't used in production.
        bundlePath: "",
        filename: "",
        appPaths: []
    },
    userland: {
        loaderTree: tree
    }
});

//# sourceMappingURL=app-page.js.map

/***/ }),

/***/ 37907:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 67023))

/***/ }),

/***/ 67023:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  KataForm: () => (/* binding */ KataForm)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/zod/lib/index.mjs
var lib = __webpack_require__(19098);
// EXTERNAL MODULE: ./node_modules/axios/lib/axios.js + 46 modules
var axios = __webpack_require__(93258);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./node_modules/@hookform/resolvers/zod/dist/zod.mjs + 1 modules
var zod = __webpack_require__(83894);
// EXTERNAL MODULE: ./node_modules/react-hook-form/dist/index.esm.mjs
var index_esm = __webpack_require__(66558);
// EXTERNAL MODULE: ./node_modules/react-hot-toast/dist/index.mjs + 1 modules
var dist = __webpack_require__(10345);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/trash.js
var trash = __webpack_require__(51734);
// EXTERNAL MODULE: ./node_modules/next/navigation.js
var navigation = __webpack_require__(57114);
// EXTERNAL MODULE: ./components/ui/input.tsx
var input = __webpack_require__(5538);
// EXTERNAL MODULE: ./components/ui/button.tsx
var ui_button = __webpack_require__(44368);
// EXTERNAL MODULE: ./node_modules/next-cloudinary/dist/index.js
var next_cloudinary_dist = __webpack_require__(14835);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/image-plus.js
var image_plus = __webpack_require__(7805);
;// CONCATENATED MODULE: ./components/ui/image-upload.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 





const ImageUpload = ({ disabled, onChange, onRemove, value })=>{
    const [isMounted, setIsMounted] = (0,react_.useState)(false);
    (0,react_.useEffect)(()=>{
        setIsMounted(true);
    }, []);
    const onUpload = (result)=>{
        onChange(result.info.secure_url);
    };
    if (!isMounted) {
        return null;
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "mb-4 flex items-center gap-4",
                children: value.map((url)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "relative w-[50%] h-[50%] rounded-md overflow-hidden",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "z-10 absolute top-2 right-2",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(ui_button/* Button */.z, {
                                    type: "button",
                                    onClick: ()=>onRemove(url),
                                    variant: "destructive",
                                    size: "sm",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(trash/* default */.Z, {
                                        className: "h-4 w-4"
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("video", {
                                className: "object-cover w-[100%]",
                                src: url,
                                controls: true
                            })
                        ]
                    }, url))
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(next_cloudinary_dist.CldUploadWidget, {
                onUpload: onUpload,
                uploadPreset: "z7t6wpvd",
                children: ({ open })=>{
                    const onClick = ()=>{
                        open();
                    };
                    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ui_button/* Button */.z, {
                        type: "button",
                        disabled: disabled,
                        variant: "secondary",
                        onClick: onClick,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(image_plus/* default */.Z, {
                                className: "h-4 w-4 mr-2"
                            }),
                            "Upload an Videos"
                        ]
                    });
                }
            })
        ]
    });
};
/* harmony default export */ const image_upload = (ImageUpload);

// EXTERNAL MODULE: ./components/ui/form.tsx + 1 modules
var ui_form = __webpack_require__(1753);
// EXTERNAL MODULE: ./components/ui/separator.tsx
var separator = __webpack_require__(451);
// EXTERNAL MODULE: ./components/ui/heading.tsx
var heading = __webpack_require__(51673);
// EXTERNAL MODULE: ./components/modals/alert-modal.tsx + 2 modules
var alert_modal = __webpack_require__(98804);
// EXTERNAL MODULE: ./node_modules/@radix-ui/react-select/dist/index.mjs + 3 modules
var react_select_dist = __webpack_require__(90045);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/check.js
var check = __webpack_require__(1264);
// EXTERNAL MODULE: ./node_modules/lucide-react/dist/esm/icons/chevron-down.js
var chevron_down = __webpack_require__(19458);
// EXTERNAL MODULE: ./lib/utils.ts
var utils = __webpack_require__(12857);
;// CONCATENATED MODULE: ./components/ui/select.tsx
/* __next_internal_client_entry_do_not_use__ Select,SelectGroup,SelectValue,SelectTrigger,SelectContent,SelectLabel,SelectItem,SelectSeparator auto */ 





const Select = react_select_dist/* Root */.fC;
const SelectGroup = react_select_dist/* Group */.ZA;
const SelectValue = react_select_dist/* Value */.B4;
const SelectTrigger = /*#__PURE__*/ react_.forwardRef(({ className, children, ...props }, ref)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_select_dist/* Trigger */.xz, {
        ref: ref,
        className: (0,utils.cn)("flex h-10 w-full items-center justify-between rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50", className),
        ...props,
        children: [
            children,
            /*#__PURE__*/ jsx_runtime_.jsx(react_select_dist/* Icon */.JO, {
                asChild: true,
                children: /*#__PURE__*/ jsx_runtime_.jsx(chevron_down/* default */.Z, {
                    className: "h-4 w-4 opacity-50"
                })
            })
        ]
    }));
SelectTrigger.displayName = react_select_dist/* Trigger */.xz.displayName;
const SelectContent = /*#__PURE__*/ react_.forwardRef(({ className, children, position = "popper", ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx(react_select_dist/* Portal */.h_, {
        children: /*#__PURE__*/ jsx_runtime_.jsx(react_select_dist/* Content */.VY, {
            ref: ref,
            className: (0,utils.cn)("relative z-50 min-w-[8rem] overflow-hidden rounded-md border bg-popover text-popover-foreground shadow-md data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2", position === "popper" && "data-[side=bottom]:translate-y-1 data-[side=left]:-translate-x-1 data-[side=right]:translate-x-1 data-[side=top]:-translate-y-1", className),
            position: position,
            ...props,
            children: /*#__PURE__*/ jsx_runtime_.jsx(react_select_dist/* Viewport */.l_, {
                className: (0,utils.cn)("p-1", position === "popper" && "h-[var(--radix-select-trigger-height)] w-full min-w-[var(--radix-select-trigger-width)]"),
                children: children
            })
        })
    }));
SelectContent.displayName = react_select_dist/* Content */.VY.displayName;
const SelectLabel = /*#__PURE__*/ react_.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx(react_select_dist/* Label */.__, {
        ref: ref,
        className: (0,utils.cn)("py-1.5 pl-8 pr-2 text-sm font-semibold", className),
        ...props
    }));
SelectLabel.displayName = react_select_dist/* Label */.__.displayName;
const SelectItem = /*#__PURE__*/ react_.forwardRef(({ className, children, ...props }, ref)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_select_dist/* Item */.ck, {
        ref: ref,
        className: (0,utils.cn)("relative flex w-full cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50", className),
        ...props,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                className: "absolute left-2 flex h-3.5 w-3.5 items-center justify-center",
                children: /*#__PURE__*/ jsx_runtime_.jsx(react_select_dist/* ItemIndicator */.wU, {
                    children: /*#__PURE__*/ jsx_runtime_.jsx(check/* default */.Z, {
                        className: "h-4 w-4"
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(react_select_dist/* ItemText */.eT, {
                children: children
            })
        ]
    }));
SelectItem.displayName = react_select_dist/* Item */.ck.displayName;
const SelectSeparator = /*#__PURE__*/ react_.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ jsx_runtime_.jsx(react_select_dist/* Separator */.Z0, {
        ref: ref,
        className: (0,utils.cn)("-mx-1 my-1 h-px bg-muted", className),
        ...props
    }));
SelectSeparator.displayName = react_select_dist/* Separator */.Z0.displayName;


;// CONCATENATED MODULE: ./app/(root)/(routes)/kata/[kataId]/components/kata-form.tsx
/* __next_internal_client_entry_do_not_use__ KataForm auto */ 
















const formSchema = lib/* object */.Ry({
    name: lib/* string */.Z_().min(1),
    videos: lib/* object */.Ry({
        url: lib/* string */.Z_()
    }).array(),
    serviceId: lib/* string */.Z_().min(1),
    categoryId: lib/* string */.Z_().min(1)
});
const KataForm = ({ initialData, categories, services })=>{
    const params = (0,navigation.useParams)();
    const router = (0,navigation.useRouter)();
    const [open, setOpen] = (0,react_.useState)(false);
    const [loading, setLoading] = (0,react_.useState)(false);
    const title = initialData ? "Edit Kata" : "Create Kata";
    const description = initialData ? "Edit a Kata." : "Add a new Kata";
    const toastMessage = initialData ? "Kata updated." : "Kata created.";
    const action = initialData ? "Save changes" : "Create";
    const form = (0,index_esm/* useForm */.cI)({
        resolver: (0,zod/* zodResolver */.F)(formSchema),
        defaultValues: initialData || {
            name: "",
            videos: [],
            serviceId: "",
            categoryId: ""
        }
    });
    const onSubmit = async (data)=>{
        console.log(data);
        try {
            setLoading(true);
            if (initialData) {
                await axios/* default */.Z.patch(`/api/kata/${params.kataId}`, data);
            } else {
                await axios/* default */.Z.post(`/api/kata`, data);
            }
            router.refresh();
            router.push(`/kata`);
            dist/* toast */.Am.success(toastMessage);
        } catch (error) {
            dist/* toast */.Am.error("Something went wrong.");
        } finally{
            setLoading(false);
        }
    };
    const onDelete = async ()=>{
        try {
            setLoading(true);
            await axios/* default */.Z.delete(`/api/kata/${params.kataId}`);
            router.refresh();
            router.push(`/kata`);
            dist/* toast */.Am.success("Product deleted.");
        } catch (error) {
            dist/* toast */.Am.error("Make sure you deaactive product.");
        } finally{
            setLoading(false);
            setOpen(false);
        }
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(alert_modal/* AlertModal */.V, {
                isOpen: open,
                onClose: ()=>setOpen(false),
                onConfirm: onDelete,
                loading: loading
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex items-center justify-between",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(heading/* Heading */.X, {
                        title: title,
                        description: description
                    }),
                    initialData && /*#__PURE__*/ jsx_runtime_.jsx(ui_button/* Button */.z, {
                        disabled: loading,
                        variant: "destructive",
                        size: "sm",
                        onClick: ()=>setOpen(true),
                        children: /*#__PURE__*/ jsx_runtime_.jsx(trash/* default */.Z, {
                            className: "h-4 w-4"
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(separator.Separator, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(ui_form/* Form */.l0, {
                ...form,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
                    onSubmit: form.handleSubmit(onSubmit),
                    className: "space-y-8 w-full",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                            className: "text-black font-bold text-xl",
                            children: "Kata"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "md:grid md:grid-cols-3 gap-8",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(ui_form/* FormField */.Wi, {
                                    control: form.control,
                                    name: "name",
                                    render: ({ field })=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)(ui_form/* FormItem */.xJ, {
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx(ui_form/* FormLabel */.lX, {
                                                    className: "font-bold text-md",
                                                    children: "Name"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(ui_form/* FormControl */.NI, {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(input/* Input */.I, {
                                                        disabled: loading,
                                                        placeholder: "Product name",
                                                        ...field
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(ui_form/* FormMessage */.zG, {})
                                            ]
                                        })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(ui_form/* FormField */.Wi, {
                                    control: form.control,
                                    name: "categoryId",
                                    render: ({ field })=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)(ui_form/* FormItem */.xJ, {
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx(ui_form/* FormLabel */.lX, {
                                                    className: "font-bold text-md",
                                                    children: "Category"
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Select, {
                                                    disabled: loading,
                                                    onValueChange: field.onChange,
                                                    value: field.value,
                                                    defaultValue: field.value,
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx(ui_form/* FormControl */.NI, {
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx(SelectTrigger, {
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx(SelectValue, {
                                                                    defaultValue: field.value,
                                                                    placeholder: "Select a category"
                                                                })
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx(SelectContent, {
                                                            children: categories.map((category)=>/*#__PURE__*/ jsx_runtime_.jsx(SelectItem, {
                                                                    value: category.id,
                                                                    children: category.name
                                                                }, category.id))
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(ui_form/* FormMessage */.zG, {})
                                            ]
                                        })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(ui_form/* FormField */.Wi, {
                                    control: form.control,
                                    name: "serviceId",
                                    render: ({ field })=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)(ui_form/* FormItem */.xJ, {
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx(ui_form/* FormLabel */.lX, {
                                                    className: "font-bold text-md",
                                                    children: "Service"
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Select, {
                                                    disabled: loading,
                                                    onValueChange: field.onChange,
                                                    value: field.value,
                                                    defaultValue: field.value,
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx(ui_form/* FormControl */.NI, {
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx(SelectTrigger, {
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx(SelectValue, {
                                                                    defaultValue: field.value,
                                                                    placeholder: "Select a service"
                                                                })
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx(SelectContent, {
                                                            children: services.map((service)=>/*#__PURE__*/ jsx_runtime_.jsx(SelectItem, {
                                                                    value: service.id,
                                                                    children: service.name
                                                                }, service.id))
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(ui_form/* FormMessage */.zG, {})
                                            ]
                                        })
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "md:grid md:grid-cols-1 gap-8",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(ui_form/* FormField */.Wi, {
                                control: form.control,
                                name: "videos",
                                render: ({ field })=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)(ui_form/* FormItem */.xJ, {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(ui_form/* FormLabel */.lX, {
                                                children: "Videos"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx(ui_form/* FormControl */.NI, {
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(image_upload, {
                                                    value: field.value.map((videos)=>videos.url),
                                                    disabled: loading,
                                                    onChange: (url)=>field.onChange([
                                                            ...field.value,
                                                            {
                                                                url
                                                            }
                                                        ]),
                                                    onRemove: (url)=>field.onChange([
                                                            ...field.value.filter((current)=>current.url !== url)
                                                        ])
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx(ui_form/* FormMessage */.zG, {})
                                        ]
                                    })
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(ui_button/* Button */.z, {
                            disabled: loading,
                            className: "ml-auto",
                            type: "submit",
                            children: action
                        })
                    ]
                })
            })
        ]
    });
};


/***/ }),

/***/ 11564:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./lib/prisma.ts
var prisma = __webpack_require__(17196);
// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(61363);
;// CONCATENATED MODULE: ./app/(root)/(routes)/kata/[kataId]/components/kata-form.tsx

const proxy = (0,module_proxy.createProxy)(String.raw`C:\Users\LEGION\Documents\AAKHUL\DiSign\App\disign-admin\app\(root)\(routes)\kata\[kataId]\components\kata-form.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;

const e0 = proxy["KataForm"];

;// CONCATENATED MODULE: ./app/(root)/(routes)/kata/[kataId]/page.tsx



const KataPage = async ({ params })=>{
    const kata = await prisma/* default */.Z.kata.findUnique({
        where: {
            id: params.kataId
        },
        include: {
            category: true,
            service: true,
            videos: true
        }
    });
    const categories = await prisma/* default */.Z.category.findMany({
        orderBy: {
            createdAt: "desc"
        }
    });
    const services = await prisma/* default */.Z.service.findMany({
        orderBy: {
            createdAt: "desc"
        }
    });
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "flex-col",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "flex-1 space-y-4 p-11 pt-6",
            children: /*#__PURE__*/ jsx_runtime_.jsx(e0, {
                initialData: kata,
                services: services,
                categories: categories
            })
        })
    });
};
/* harmony default export */ const page = (KataPage);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [587,778,268,763,672,266,164,925,766,577], () => (__webpack_exec__(5061)));
module.exports = __webpack_exports__;

})();